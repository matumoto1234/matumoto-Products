This program was made by matumoto.
How to use this program.

1. Install typing_game.zip
2. Set the 'text.txt' at above directory the 'typing_game.exe'.
3. Play the 'typing_game.exe'.